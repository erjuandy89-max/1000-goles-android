# 1.000 Goles — Neon Matchday Edition

Rediseño visual de la edición 2026, sin modificar la lógica de juego ni los datos de futbolistas.

## Qué incluye

- Pantalla nativa Android rediseñada (estadio neón, menús mejorados y dos modos).
- Interfaz HTML de partidas, menú online, clasificación, marcadores y configuración con nuevo estilo.
- Icono vectorial con anillo verde neón.
- Conexión online fija: `https://one000-goles-online.onrender.com`.
- Para evitar conflictos con las APK anteriores, el identificador de las compilaciones `debug` usa el sufijo `.neonmatchday`.

## APK

Este ZIP es un proyecto de Android, NO un APK instalable. Para crear la APK:

1. Descomprime el proyecto de este ZIP en Android Studio o súbelo a GitHub Actions.
2. Desde la carpeta `android`, ejecuta `gradle :app:assembleDebug` con Java 17 y Android SDK 36.
3. La salida es `app/build/outputs/apk/debug/app-debug.apk`.
4. Antes de instalar, confirma la firma y prueba la app en un dispositivo Android.

La compilación `debug` se firma automáticamente por el entorno de compilación y no actualizará una APK firmada con otra clave. El sufijo `.neonmatchday` permite instalarla por separado.

Para que el modo online se vea con el nuevo estilo, también hay que actualizar el `server.js` del repositorio que despliega Render, usando el paquete del servidor entregado aparte.

## Compilar en GitHub Actions desde el móvil

El archivo `.github/workflows/build-neon-matchday.yml` debe estar **en la raíz del repositorio GitHub**, y la carpeta `android/` debe estar a su lado. No subas el ZIP sin descomprimir esperando que GitHub lo convierta en archivos.

Tras subir los archivos, abre `Actions` → `Compilar APK - 1000 Goles Neon Matchday` → `Run workflow`. Descarga `1000-Goles-Neon-Matchday-APK` en la sección `Artifacts` y extrae `app-debug.apk`.

Este proyecto no contiene el servidor Node/Render: la APK online abre `https://one000-goles-online.onrender.com` y requiere que esa dirección sirva la web del juego y el WebSocket `/ws`. Esto se comprueba aparte con dos móviles.

La versión de depuración tiene un identificador distinto (`com.erjuandy.goles1000.neonmatchday`) y **no actualiza** una aplicación antigua; se instala junto a ella.


## Ultimate Pique Edition · 24/11/2026

- Portada azul cian y estadio nocturno: `app/src/main/assets/neon-theme.css` y `neon-hero.webp`.
- El `index.html` mantiene los IDs y el JavaScript del juego; añade diseño y CTA.
- Android `MainActivity` abre la portada HTML local directamente y enlaza online con una navegación `milgoles://online` interceptada solo dentro de WebView; sin `JavascriptInterface`.
- El modo online sigue cargando el servidor HTTPS de Render y requiere desplegar allí el frontend/backend que lo soporta.
- Paquete debug separado `.ultimatepique`; evita conflictos con APKs Neon previas, pero no resuelve por sí solo la firma persistente de **futuras** actualizaciones.
- `versionCode 11`, `versionName 11.0.0-ultimate-pique`. No para Play Store ni producción sin firma estable.
- Para modificar colores/diseño posteriormente, edita `neon-theme.css` y vuelve a empaquetar el proyecto ZIP; el workflow del repositorio recompila al sustituir el ZIP exacto.
