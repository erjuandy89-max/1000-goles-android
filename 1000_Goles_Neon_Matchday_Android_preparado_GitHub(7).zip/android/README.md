# 1.000 Goles — Neon Matchday Edition

Rediseño visual de la edición 2026, sin modificar la lógica de juego ni los datos de futbolistas.

## Qué incluye

- Pantalla nativa Android rediseñada (estadio neón, menús mejorados y dos modos).
- Interfaz HTML de partidas, menú online, clasificación, marcadores y configuración con nuevo estilo.
- Icono vectorial con anillo verde neón.
- Conexión online fija: `https://one000-goles-online.onrender.com`.
- Para evitar conflictos con las APK anteriores, el identificador de las compilaciones `debug` usa el sufijo `.neonmatchday`.

## APK

Este ZIP es un proyecto de Android, NO un APK instalable. Para crear la APK:

1. Descomprime el proyecto de este ZIP en Android Studio o súbelo a GitHub Actions.
2. Desde la carpeta `android`, ejecuta `gradle :app:assembleDebug` con Java 17 y Android SDK 36.
3. La salida es `app/build/outputs/apk/debug/app-debug.apk`.
4. Antes de instalar, confirma la firma y prueba la app en un dispositivo Android.

La compilación `debug` se firma automáticamente por el entorno de compilación y no actualizará una APK firmada con otra clave. El sufijo `.neonmatchday` permite instalarla por separado.

Para que el modo online se vea con el nuevo estilo, también hay que actualizar el `server.js` del repositorio que despliega Render, usando el paquete del servidor entregado aparte.

## Compilar en GitHub Actions desde el móvil

El archivo `.github/workflows/build-neon-matchday.yml` debe estar **en la raíz del repositorio GitHub**, y la carpeta `android/` debe estar a su lado. No subas el ZIP sin descomprimir esperando que GitHub lo convierta en archivos.

Tras subir los archivos, abre `Actions` → `Compilar APK - 1000 Goles Neon Matchday` → `Run workflow`. Descarga `1000-Goles-Neon-Matchday-APK` en la sección `Artifacts` y extrae `app-debug.apk`.

Este proyecto no contiene el servidor Node/Render: la APK online abre `https://one000-goles-online.onrender.com` y requiere que esa dirección sirva la web del juego y el WebSocket `/ws`. Esto se comprueba aparte con dos móviles.

La versión de depuración tiene un identificador distinto (`com.erjuandy.goles1000.neonmatchday`) y **no actualiza** una aplicación antigua; se instala junto a ella.


## Ultimate Pique Edition · 24/11/2026

- Portada azul cian y estadio nocturno: `app/src/main/assets/neon-theme.css` y `neon-hero.webp`.
- El `index.html` mantiene los IDs y el JavaScript del juego; añade diseño y CTA.
- Android `MainActivity` abre la portada HTML local directamente y enlaza online con una navegación `milgoles://online` interceptada solo dentro de WebView; sin `JavascriptInterface`.
- El modo online sigue cargando el servidor HTTPS de Render y requiere desplegar allí el frontend/backend que lo soporta.
- Paquete debug separado `.ultimatepique`; evita conflictos con APKs Neon previas, pero no resuelve por sí solo la firma persistente de **futuras** actualizaciones.
- `versionCode 11`, `versionName 11.0.0-ultimate-pique`. No para Play Store ni producción sin firma estable.
- Para modificar colores/diseño posteriormente, edita `neon-theme.css` y vuelve a empaquetar el proyecto ZIP; el workflow del repositorio recompila al sustituir el ZIP exacto.


## Ultimate Pique: tema azul global (noviembre 2026)

El archivo `app/src/main/assets/ultimate-global.css` es **la fuente única de estilos comunes**
para partida local, marcadores, formularios online, salas, resultados y modales.
Se carga mediante `<link>` **después de** `neon-theme.css` en el HTML integrado.

La `MainActivity` carga la versión online desde Render (sin modificar su servidor)
y, al terminar la navegación HTTPS, inyecta el **mismo CSS local** mediante un elemento
`<style id="ultimate-pique-global-css">`. Así la APK presenta el nuevo aspecto en
las pantallas remotas, sin tocar mensajes WebSocket, salas ni turnos. Si Render
aplica una política CSP que impida estilos inyectados, será necesario desplegar
allí el CSS o la portada HTML y comprobar la política; no se ha verificado aún
la respuesta del servidor ni una partida entre dos teléfonos.

**No hay un servicio de actualizaciones visuales instantáneas** en esta entrega:
los CSS incrustados en el APK requieren una nueva compilación. Para cambios solo
de CSS, el workflow incluido puede aplicar el archivo raíz `ultimate-global.css`
si existe, sin reempaquetar el ZIP; se deberá subir el workflow modificado una vez.

La aplicación de prueba utiliza un `applicationId` diferente a las APK anteriores
para evitar conflictos de firma. Para próximas actualizaciones sobre el **mismo**
paquete, configurar y conservar una clave de firma estable en secretos de GitHub.
No subir jamás la clave privada al repositorio.
