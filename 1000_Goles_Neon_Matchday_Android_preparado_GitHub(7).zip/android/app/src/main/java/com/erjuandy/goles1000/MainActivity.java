package com.erjuandy.goles1000;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;


/**
 * Android wrapper for 1.000 Goles.
 * Offline: bundled HTML via WebViewAssetLoader (without internet).
 * Online: loads the same deployed game from the owner's HTTPS Render endpoint.
 * No JavaScriptInterface or dangerous runtime permissions.
 */
public class MainActivity extends Activity {
    private static final String LOCAL_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final String ONLINE_URL = "https://one000-goles-online.onrender.com";
    private static final int PICK_FILE = 42;
    private static final int BACKGROUND = Color.rgb(8, 10, 16);
    private static final int GREEN = Color.rgb(0, 207, 255);
    private static final int WHITE = Color.rgb(249, 252, 255);
    private static final int MUTED = Color.rgb(170, 184, 195);

    private LinearLayout root;
    private WebView web;
    private WebViewAssetLoader assetLoader;
    private String currentMode = "home";
    private String globalThemeCss;
    private ValueCallback<Uri[]> fileChooser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BACKGROUND);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets pad = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                root.setPadding(pad.left, pad.top, pad.right, pad.bottom);
            } else {
                root.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        setContentView(root);
        root.requestApplyInsets();
        showHome();
    }

    private int dp(float n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable background(int color, int border) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(16));
        if (border != Color.TRANSPARENT) bg.setStroke(dp(1), border);
        return bg;
    }

    private Button button(String caption, boolean main, View.OnClickListener action) {
        Button b = new Button(this);
        b.setText(caption);
        b.setTextSize(16);
        b.setAllCaps(false);
        b.setTextColor(main ? BACKGROUND : WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(14), dp(10), dp(14), dp(10));
        b.setBackground(background(main ? GREEN : 0xff16304a, main ? Color.TRANSPARENT : 0xff335573));
        b.setOnClickListener(action);
        b.setMinHeight(dp(54));
        return b;
    }

    private void addButton(LinearLayout box, Button b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(12);
        box.addView(b, lp);
    }

    private void destroyWeb() {
        if (web != null) {
            web.stopLoading();
            root.removeView(web);
            web.destroy();
            web = null;
        }
    }

    private GradientDrawable gradient(int left, int right, int stroke, int radius) {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{left, right});
        gd.setCornerRadius(dp(radius));
        if (stroke != Color.TRANSPARENT) gd.setStroke(dp(1), stroke);
        return gd;
    }

    private void spaced(LinearLayout parent, View view, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        parent.addView(view, lp);
    }

    private TextView displayText(String value, int size, int color) {
        TextView t = text(value, size, color, true);
        t.setTypeface(Typeface.create("sans-serif-condensed-black", Typeface.BOLD));
        t.setGravity(Gravity.START);
        if (Build.VERSION.SDK_INT >= 21) t.setLetterSpacing(0.035f);
        return t;
    }

    private LinearLayout modeTile(String number, String title, String sub,
                                  boolean local, View.OnClickListener action) {
        int foreground = local ? 0xff10190a : WHITE;
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.START);
        tile.setPadding(dp(22), dp(18), dp(22), dp(17));
        tile.setBackground(gradient(local ? 0xffbaff41 : 0xff29366c,
                local ? 0xff8bde30 : 0xff131b38,
                local ? 0xffceff90 : 0xff596fc5, 20));
        TextView tag = displayText(number, 11, foreground);
        tile.addView(tag);
        TextView name = displayText(title, 28, foreground);
        spaced(tile, name, 14);
        TextView description = text(sub, 13, foreground, false);
        description.setGravity(Gravity.START);
        spaced(tile, description, 5);
        TextView arrow = displayText("ENTRAR   ↗", 13, foreground);
        spaced(tile, arrow, 13);
        tile.setClickable(true);
        tile.setFocusable(true);
        tile.setOnClickListener(action);
        tile.setContentDescription(number + ". " + title + ". " + sub);
        return tile;
    }

    /** The home page is the actual game HTML so design updates need no native redesign. */
    private void showHome() {
        openGame("home", LOCAL_URL);
    }

    private void openOffline() { showHome(); }

    private void openOnline() { openGame("online", ONLINE_URL); }

    private void openGame(String mode, String url) {
        destroyWeb();
        currentMode = mode;
        root.removeAllViews();
        if ("online".equals(mode)) {
            LinearLayout toolbar = new LinearLayout(this);
            toolbar.setBackgroundColor(BACKGROUND);
            toolbar.setGravity(Gravity.CENTER_VERTICAL);
            toolbar.setPadding(dp(6), 0, dp(8), 0);
            root.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(48)));
            Button home = button("‹  Inicio", false, v -> showHome());
            home.setTextSize(13);
            toolbar.addView(home, new LinearLayout.LayoutParams(dp(105), dp(42)));
            TextView label = text("1.000 Goles · Online", 14, WHITE, true);
            toolbar.addView(label, new LinearLayout.LayoutParams(0, -2, 1f));
            Button share = button("Invitar", false, v -> shareOnlineRoom());
            share.setTextSize(13);
            toolbar.addView(share, new LinearLayout.LayoutParams(dp(90), dp(42)));
        }

        web = new WebView(this);
        web.setBackgroundColor(BACKGROUND);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        web.getSettings().setSupportMultipleWindows(false);
        web.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view,
                    WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri target = request.getUrl();
                if (!request.isForMainFrame()) return false;
                if ("milgoles".equalsIgnoreCase(target.getScheme())
                        && "online".equalsIgnoreCase(target.getHost())
                        && "home".equals(currentMode)) {
                    openOnline();
                    return true;
                }
                if ("https".equals(target.getScheme())) {
                    if ("appassets.androidplatform.net".equalsIgnoreCase(target.getHost())) return false;
                    String currentHost = "online".equals(currentMode)
                            ? Uri.parse(ONLINE_URL).getHost() : null;
                    if (currentHost != null && currentHost.equalsIgnoreCase(target.getHost())) return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, target));
                } catch (ActivityNotFoundException ignored) {
                    Toast.makeText(MainActivity.this, "No hay aplicación para abrir este enlace", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String loadedUrl) {
                if ("online".equals(currentMode) && loadedUrl.startsWith(ONLINE_URL)) {
                    // Render hosts the active multiplayer game. Apply the SAME blue theme
                    // stored in APK assets without replacing its working network/game code.
                    // The style element persists across SPA screen changes.
                    applyGlobalOnlineTheme(view);
                }
                if ("home".equals(currentMode) && loadedUrl.startsWith(LOCAL_URL)) {
                    // Only the local home button is intercepted. In a browser, original JS works normally.
                    // No native JavaScript bridge or exposed privileged methods are required.
                    view.evaluateJavascript("(function(){var b=document.getElementById('go-online');" +
                        "if(b&&!b.dataset.nativeOnline){b.dataset.nativeOnline='1';" +
                        "b.addEventListener('click',function(e){e.preventDefault();" +
                        "e.stopImmediatePropagation();location.href='milgoles://online';},true);}})();", null);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && "online".equals(currentMode)) {
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Sin conexión con el servidor")
                            .setMessage("No se ha podido cargar la partida online. Puedes reintentar o jugar sin Internet.")
                            .setPositiveButton("Reintentar", (d, w) -> view.reload())
                            .setNegativeButton("Jugar sin conexión", (d, w) -> openOffline())
                            .show();
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileChooser != null) fileChooser.onReceiveValue(null);
                fileChooser = callback;
                try {
                    startActivityForResult(params.createIntent(), PICK_FILE);
                    return true;
                } catch (ActivityNotFoundException ex) {
                    fileChooser = null;
                    return false;
                }
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1f));
        web.loadUrl(url);
    }

    /** One source of truth for styling both local assets and remote online screens. */
    private void applyGlobalOnlineTheme(WebView view) {
        if (globalThemeCss == null) {
            try (InputStream in = getAssets().open("ultimate-global.css");
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] chunk = new byte[8192];
                int count;
                while ((count = in.read(chunk)) != -1) out.write(chunk, 0, count);
                globalThemeCss = new String(out.toByteArray(), StandardCharsets.UTF_8);
            } catch (Exception ignored) {
                return; // Network gameplay still works even if the cosmetic asset is absent.
            }
        }
        String js = "(function(){" +
                "var id='ultimate-pique-global-css';" +
                "var s=document.getElementById(id);" +
                "if(!s){s=document.createElement('style');s.id=id;document.head.appendChild(s);}" +
                "s.textContent=" + JSONObject.quote(globalThemeCss) + ";" +
                "})();";
        view.evaluateJavascript(js, null);
    }

    private void shareOnlineRoom() {
        if (web == null || !"online".equals(currentMode)) return;
        web.evaluateJavascript("(function(){const e=document.getElementById('online-room-code');return e?e.textContent.trim():''})();", result -> {
            String code = "";
            try { code = new JSONArray("[" + result + "]").getString(0); }
            catch (Exception ignored) { }
            String shareUrl = ONLINE_URL;
            String msg;
            if (code.matches("[A-HJ-NP-Z2-9]{6}")) {
                msg = "¡Juega conmigo a 1.000 Goles! ⚽ Entra aquí: "
                        + shareUrl + "#sala=" + code;
            } else {
                msg = "¡Juega conmigo a 1.000 Goles! ⚽ " + shareUrl;
            }
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, msg);
            startActivity(Intent.createChooser(send, "Compartir por WhatsApp u otra aplicación"));
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && fileChooser != null) {
            Uri[] chosen = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileChooser.onReceiveValue(chosen);
            fileChooser = null;
        }
    }

    @Override
    public void onBackPressed() {
        if ("home".equals(currentMode)) {
            super.onBackPressed();
        } else if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            showHome();
        }
    }

    @Override
    protected void onDestroy() {
        destroyWeb();
        super.onDestroy();
    }
}
