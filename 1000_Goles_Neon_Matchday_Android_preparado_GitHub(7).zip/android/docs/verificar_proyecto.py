#!/usr/bin/env python3
"""Checks the offline asset and basic Android project wiring without Android SDK."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
html = (root / 'app/src/main/assets/index.html').read_text(encoding='utf-8')
java = (root / 'app/src/main/java/com/erjuandy/goles1000/MainActivity.java').read_text(encoding='utf-8')
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
build = (root / 'app/build.gradle').read_text(encoding='utf-8')
global_css = (root / 'app/src/main/assets/ultimate-global.css').read_text(encoding='utf-8')
checks = {
  'HTML incluido': len(html)>4_000_000,
  '70 clubes': 'CLUBS_DB' in html,
  'modalidad 500 exactos': 'exact500' in html,
  'modo local de verdad': 'WebViewAssetLoader' in java and 'openOffline()' in java,
  'modo online por URL': 'openOnline()' in java and 'ONLINE_URL' in java and 'one000-goles-online.onrender.com' in java,
  'sin JS bridge inseguro': 'addJavascriptInterface(' not in java,
  'API 36': 'targetSdk 36' in build,
  'Internet': 'android.permission.INTERNET' in manifest,
  'sin backups': 'android:allowBackup="false"' in manifest,
  'sin tráfico HTTP': 'android:usesCleartextTraffic="false"' in manifest,
  'tema global cargado localmente': 'href="ultimate-global.css"' in html,
  'tema aplicado al online remoto': 'applyGlobalOnlineTheme(view)' in java and 'ultimate-global.css' in java,
  'estilos de partida y sala online': '#game .scoreboard' in global_css and '#online-screen' in global_css,
  'app de prueba independiente': "applicationId 'com.erjuandy.goles1000.global'" in build,
}
for name, passed in checks.items():
    print(('OK  ' if passed else 'FAIL') + name)
if not all(checks.values()): raise SystemExit(1)
