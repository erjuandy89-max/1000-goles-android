# Pruebas antes de Play Store

- [ ] Instala la APK `debug` de GitHub Actions; abre sin conexión.
- [ ] Local: iniciar, jugar y acabar partida normal.
- [ ] Local: 500 exactos: 498 + 5 -> 497.
- [ ] Local: volver, cerrar, reabrir, retomar partida si el juego lo permite.
- [ ] Online: abrir la URL HTTPS de Render configurada en MainActivity (sin pestaña de configuración).
- [ ] Online: 2 móviles con redes distintas; crear, unirse, empezar, puntuar.
- [ ] Online: comprobar la invitación nativa por WhatsApp.
- [ ] Online: probar salas de 3 y 4 personas; probar 500 exactos.
- [ ] Online: desconectar un móvil y regresar.
- [ ] Online: reiniciar Render en una prueba controlada: comprobar limitación de partidas en memoria.
- [ ] Revisar tamaño de texto, teclado, navegación atrás y servicios gratuitos suspendidos.
- [ ] Preparar política de privacidad, formulario de datos, iconos, capturas y firma para Play.
